/**
 * SeniorBazaar - Home Page Logic
 * Renders campus tips, dynamic category item counts, and latest listings.
 */

var TIPS = [
  "Prices on SeniorBazaar are 60%–80% below retail store prices to keep campus life affordable.",
  "Meet in busy campus locations like the Central Library or Student Food Court.",
  "Check books and test calculators/circuits in person before paying.",
  "Finished your semester? List your books early before the next term rush starts.",
  "Donating unused lab coats or notes helps a junior start their college journey.",
  "Price your items fairly — 20% to 40% of original MRP makes them sell fast to campus mates."
];

var lastTip = -1;

function newTip() {
  var next;
  do { next = Math.floor(Math.random() * TIPS.length); } while (next === lastTip && TIPS.length > 1);
  lastTip = next;
  var el = document.getElementById("quote");
  if (!el) return;
  el.style.opacity = "0";
  setTimeout(function() { el.textContent = TIPS[next]; el.style.opacity = "1"; }, 150);
}

(function initHome() {
  lastTip = Math.floor(Date.now() / 86400000) % TIPS.length;
  if ($("#quote")) $("#quote").textContent = TIPS[lastTip];

  var items = allItems();

  Object.keys(CATEGORIES).forEach(function(k) {
    var count = items.filter(function(it) { return it.category === k; }).length;
    var badge = $("#n-" + k);
    if (badge) badge.textContent = count + (count === 1 ? " item" : " items");
  });

  if ($("#stat-items")) $("#stat-items").textContent = items.length;

  var latest = $("#latest");
  if (latest) {
    latest.innerHTML = "";
    items.slice().sort(function(a, b) { return b.id - a.id; }).slice(0, 4).forEach(function(it) {
      latest.appendChild(makeCard(it, true));
    });
    bindItemButtons(latest, initHome);
  }
})();
