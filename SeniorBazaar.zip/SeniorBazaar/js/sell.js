/**
 * SeniorBazaar - Sell or Donate Listing Logic
 * Form validation, real-time live card preview, and local persistence.
 */

var form = document.getElementById("sellForm");

function val(id) { var el = document.getElementById(id); return el ? el.value.trim() : ""; }
function radio(name) { var el = document.querySelector('input[name="' + name + '"]:checked'); return el ? el.value : ""; }
function isDonate() { return radio("type") === "donate"; }

function setError(input, msg) {
  if (!input) return false;
  var field = input.closest(".field");
  if (!field) return false;
  field.classList.toggle("invalid", !!msg);
  var errEl = field.querySelector(".err");
  if (errEl) errEl.textContent = msg || "";
  return !msg;
}

function togglePrice() {
  var donate = isDonate();
  var pField = document.getElementById("priceField");
  if (pField) pField.classList.toggle("hidden", donate);
  if (donate) {
    if ($("#sPrice")) { $("#sPrice").value = ""; setError($("#sPrice"), ""); }
    if ($("#sOriginal")) { $("#sOriginal").value = ""; }
  }
}

function updateProgress() {
  var fields = [val("sName"), val("sItem"), val("sDesc"), val("sContact")];
  if (!isDonate()) fields.push(val("sPrice"));
  var filled = fields.filter(Boolean).length;
  var pct = Math.round((filled / fields.length) * 100);

  if ($("#progress-fill")) $("#progress-fill").style.width = pct + "%";
  if ($("#progress-pct")) $("#progress-pct").textContent = pct + "%";
  if ($("#progress-text")) $("#progress-text").textContent = filled + " of " + fields.length + " filled";
}

function updatePreview() {
  var catKey = radio("category") || "books";
  var cat = CATEGORIES[catKey] || CATEGORIES.other;
  var rawPrice = parseInt(val("sPrice"), 10);
  var rawOrig = parseInt(val("sOriginal"), 10);
  var donate = isDonate();

  var previewBox = document.getElementById("preview");
  if (previewBox) {
    previewBox.innerHTML = "";
    var card = makeCard({
      category: catKey,
      icon: cat.icon,
      title: val("sItem") || "Your item title will appear here",
      desc: val("sDesc") || "Add a helpful description about condition, edition, or hostel block...",
      price: donate || isNaN(rawPrice) ? 0 : rawPrice,
      original: isNaN(rawOrig) ? 0 : rawOrig,
      name: val("sName") || "Student Seller",
      contact: val("sContact") || "98765-XXXXX"
    }, false);

    if (!donate && isNaN(rawPrice)) {
      var pTag = card.querySelector(".price");
      if (pTag) { pTag.classList.remove("free"); pTag.textContent = "₹ --"; }
    }
    previewBox.appendChild(card);
  }

  if ($("#descCount") && $("#sDesc")) $("#descCount").textContent = $("#sDesc").value.length;
}

function submitItem(e) {
  e.preventDefault();
  var ok = true;
  function check(id, msg) { if (!setError($("#" + id), val(id) ? "" : msg)) ok = false; }

  check("sName", "Your name & year is required.");
  check("sItem", "Item name is required.");
  check("sDesc", "Description is required.");

  if (!isDonate()) {
    var pVal = val("sPrice");
    if (!setError($("#sPrice"), pVal !== "" && Number(pVal) >= 0 ? "" : "Enter a valid student price, or choose Donate.")) ok = false;
  }

  var phone = val("sContact").replace(/\D/g, "");
  if (!setError($("#sContact"), phone.length === 10 ? "" : "Enter a valid 10-digit mobile number.")) ok = false;

  var errBox = $("#form-error");
  if (!ok) {
    if (errBox) { errBox.textContent = "Please fix the highlighted fields above."; errBox.classList.add("show"); }
    var firstBad = $(".field.invalid");
    if (firstBad) firstBad.scrollIntoView({ behavior: "smooth", block: "center" });
    return;
  }
  if (errBox) errBox.classList.remove("show");

  var catKey = radio("category") || "other";
  var origVal = parseInt(val("sOriginal"), 10);

  userItems.unshift({
    id: Date.now(),
    category: catKey,
    icon: (CATEGORIES[catKey] || CATEGORIES.other).icon,
    title: val("sItem"),
    desc: val("sDesc"),
    price: isDonate() ? 0 : parseInt(val("sPrice"), 10),
    original: isNaN(origVal) ? 0 : origVal,
    name: val("sName"),
    contact: phone.slice(0, 5) + "-" + phone.slice(5)
  });
  saveUserItems();

  safeSet("sb-flash", "Your item was listed successfully! 🎉");
  window.location.href = "browse.html";
}

if (form) {
  form.addEventListener("submit", submitItem);
  form.addEventListener("input", function (e) {
    var f = e.target.closest(".field");
    if (f) f.classList.remove("invalid");
    updateProgress();
    updatePreview();
  });
  form.addEventListener("change", function () {
    togglePrice();
    updateProgress();
    updatePreview();
  });
  togglePrice();
  updateProgress();
  updatePreview();
}
