/**
 * SeniorBazaar - Contact Form Logic
 * Validates campus contact/feedback submission and triggers confirmation toasts.
 */

var contactForm = document.getElementById("contactForm");

function validate(id, ok, msg) {
  var input = document.getElementById(id);
  var field = input ? input.closest(".field") : null;
  if (!field) return false;
  field.classList.toggle("invalid", !ok);
  var errEl = field.querySelector(".err");
  if (errEl) errEl.textContent = ok ? "" : msg;
  return ok;
}

if (contactForm) {
  contactForm.addEventListener("submit", function (e) {
    e.preventDefault();
    var name = (document.getElementById("cName") ? document.getElementById("cName").value : "").trim();
    var email = (document.getElementById("cEmail") ? document.getElementById("cEmail").value : "").trim();
    var msg = (document.getElementById("cMsg") ? document.getElementById("cMsg").value : "").trim();

    var okName = validate("cName", name.length >= 2, "Please enter your name.");
    var okEmail = validate("cEmail", /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email), "Please enter a valid email address.");
    var okMsg = validate("cMsg", msg.length >= 5, "Please write a brief message or question.");

    if (!(okName && okEmail && okMsg)) {
      if (window.toast) window.toast("Please correct the highlighted fields.", "error");
      return;
    }
    if (window.toast) window.toast("Thank you! Your message has been sent. We'll reply soon.");
    contactForm.reset();
  });

  contactForm.addEventListener("input", function (e) {
    var f = e.target.closest(".field");
    if (f) f.classList.remove("invalid");
  });
}
