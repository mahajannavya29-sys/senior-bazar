/**
 * SeniorBazaar - Shared Data & Store
 * Manages categories, sample seed items, and user-listed items in LocalStorage.
 */

var CATEGORIES = {
  books: { label: "Textbooks", icon: "📚" },
  notes: { label: "Notes & Stationery", icon: "📝" },
  labcoat: { label: "Lab Coats & Aprons", icon: "🥼" },
  drawing: { label: "Drawing Tools", icon: "📐" },
  calculator: { label: "Calculators", icon: "🧮" },
  electronics: { label: "Electronics & Kits", icon: "🔌" },
  hostel: { label: "Hostel Essentials", icon: "🛏️" },
  other: { label: "Other Items", icon: "📦" }
};

// Seed items priced deeply below store MRP so any student can afford them
var SEED_ITEMS = [
  { id: 8, category: "books", icon: "📚", title: "Engineering Mathematics (B.S. Grewal)", desc: "Good condition, 44th edition, no missing pages.", price: 150, original: 850, name: "Rahul (CSE, 4th Year)", contact: "98765-00001" },
  { id: 7, category: "notes", icon: "📝", title: "Data Structures & Algorithms Notes", desc: "Neat handwritten notes + previous year solved exam questions.", price: 0, original: 300, name: "Simran (IT, 3rd Year)", contact: "98765-00002" },
  { id: 6, category: "labcoat", icon: "🥼", title: "White Lab Coat (Size M)", desc: "Washed and ironed. Used for 1 year only.", price: 90, original: 450, name: "Aman (ECE, 3rd Year)", contact: "98765-00003" },
  { id: 5, category: "drawing", icon: "📐", title: "Engineering Drawing Kit (Mini Drafter)", desc: "Complete kit: mini drafter, scale, clips, and set squares.", price: 180, original: 900, name: "Karan (ME, 4th Year)", contact: "98765-00004" },
  { id: 4, category: "calculator", icon: "🧮", title: "Casio fx-991ES Plus Calculator", desc: "Scientific calculator, working 100%, original slide cover.", price: 290, original: 1300, name: "Neha (CSE, 4th Year)", contact: "98765-00005" },
  { id: 3, category: "electronics", icon: "🔌", title: "Arduino Uno Project Kit", desc: "Board, breadboard, jumper wires, ultrasonic & IR sensors.", price: 350, original: 1500, name: "Vikas (ECE, 4th Year)", contact: "98765-00006" },
  { id: 2, category: "hostel", icon: "🛏️", title: "Hostel Electric Kettle (1.5L)", desc: "Stainless steel body, auto cut-off. Great for tea/Maggi.", price: 190, original: 950, name: "Pooja (Biotech, 4th Year)", contact: "98765-00007" },
  { id: 1, category: "other", icon: "💡", title: "LED Desk Study Lamp", desc: "3 brightness modes, USB rechargeable. Giving away to any junior.", price: 0, original: 500, name: "Harpreet (Civil, 2nd Year)", contact: "98765-00008" }
];

// Helper shorthand DOM selectors
function $(s, p) { return (p || document).querySelector(s); }
function $$(s, p) { return Array.prototype.slice.call((p || document).querySelectorAll(s)); }

// LocalStorage helpers
function safeGet(k) { try { return localStorage.getItem(k); } catch (e) { return null; } }
function safeSet(k, v) { try { localStorage.setItem(k, v); } catch (e) {} }

// Load user-added items from browser storage
function loadUserItems() {
  var list = [];
  try { list = JSON.parse(safeGet("seniorbazaar_items") || safeGet("items") || "[]"); } catch (e) { list = []; }
  return list.map(function(it, i) {
    var cat = CATEGORIES[it.category] ? it.category : "other";
    return {
      id: it.id || (Date.now() + i),
      category: cat,
      icon: it.icon || CATEGORIES[cat].icon,
      title: it.title || "Untitled Item",
      desc: it.desc || "",
      price: typeof it.price === "number" ? it.price : (parseInt(it.price, 10) || 0),
      original: it.original ? parseInt(it.original, 10) : 0,
      name: it.name || "Student",
      contact: it.contact || ""
    };
  });
}

var userItems = loadUserItems();

function saveUserItems() {
  safeSet("seniorbazaar_items", JSON.stringify(userItems));
  safeSet("items", JSON.stringify(userItems));
}

function allItems() {
  return userItems.concat(SEED_ITEMS);
}

// Generate product card element with affordable student price and crossed-out actual price
function makeCard(it, interactive) {
  var card = document.createElement("article");
  card.className = "card item " + it.category;

  var cat = CATEGORIES[it.category] || CATEGORIES.other;
  var isFree = it.price === 0;
  var initial = (it.name || "S").trim().charAt(0).toUpperCase();

  var orig = it.original && it.original > it.price ? it.original : 0;
  var discountPct = orig ? Math.round((1 - (it.price / orig)) * 100) : 0;

  var priceHtml = '<div class="price-box">' +
    (isFree ? '<span class="price free">Free (Donation)</span>' : '<span class="price">₹' + it.price + '</span>') +
    (orig ? ' <span class="original-price" title="Original shop price">₹' + orig + '</span>' : '') +
    (discountPct > 0 ? ' <span class="discount-badge">' + discountPct + '% OFF</span>' : '') +
  '</div>';

  card.innerHTML =
    '<div class="item-top">' +
      '<span class="icon">' + (it.icon || cat.icon) + '</span>' +
      '<span class="tag">' + cat.label + '</span>' +
    '</div>' +
    '<h3>' + it.title + '</h3>' +
    '<p class="desc">' + it.desc + '</p>' +
    priceHtml +
    '<div class="seller">' +
      '<span class="avatar">' + initial + '</span>' +
      '<span class="seller-name">' + it.name + '</span>' +
    '</div>' +
    '<div class="item-actions">' +
      '<button type="button" class="btn-contact"' + (interactive ? ' data-contact="' + it.contact + '"' : ' disabled') + '>📞 Contact Seller</button>' +
    '</div>';

  var isMine = userItems.some(function(u) { return String(u.id) === String(it.id); });
  if (interactive && isMine) {
    var badge = document.createElement("span");
    badge.className = "badge-yours";
    badge.textContent = "Your Listing";
    card.appendChild(badge);

    var del = document.createElement("button");
    del.type = "button";
    del.className = "btn-del";
    del.title = "Delete this listing";
    del.dataset.remove = it.id;
    del.innerHTML = "🗑️";
    card.querySelector(".item-actions").appendChild(del);
  }
  return card;
}

// Reveal contact phone number or trigger call
function toggleContact(btn) {
  var num = btn.dataset.contact;
  if (!num) return;
  if (btn.classList.contains("shown")) {
    window.location.href = "tel:" + num.replace(/[^\d+]/g, "");
    return;
  }
  btn.classList.add("shown");
  btn.textContent = "📞 " + num + " (Tap to Call)";
}

// Remove listing from user's store
function removeItem(id) {
  if (!confirm("Are you sure you want to remove this listing?")) return false;
  userItems = userItems.filter(function(it) { return String(it.id) !== String(id); });
  saveUserItems();
  return true;
}

// Delegate contact and delete actions
function bindItemButtons(box, afterRemove) {
  if (!box) return;
  box.addEventListener("click", function(e) {
    var cBtn = e.target.closest("[data-contact]");
    if (cBtn) return toggleContact(cBtn);

    var dBtn = e.target.closest("[data-remove]");
    if (dBtn && removeItem(dBtn.dataset.remove)) {
      if (window.toast) window.toast("Listing removed successfully.");
      if (typeof afterRemove === "function") afterRemove();
    }
  });
}
