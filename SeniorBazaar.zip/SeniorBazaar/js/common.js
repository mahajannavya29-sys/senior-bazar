/**
 * SeniorBazaar - Common Utilities
 * Handles theme switcher (Dark/Light), mobile navigation, and toast alerts.
 */

(function () {
  var root = document.documentElement;
  var themeBtn = document.getElementById("theme-btn");

  // 1. Theme (Dark / Light)
  function applyTheme(theme) {
    root.setAttribute("data-theme", theme);
    if (themeBtn) {
      themeBtn.textContent = theme === "dark" ? "☀️" : "🌙";
      themeBtn.setAttribute("aria-label", "Switch to " + (theme === "dark" ? "light" : "dark") + " mode");
    }
  }

  var prefersDark = window.matchMedia && window.matchMedia("(prefers-color-scheme: dark)").matches;
  var savedTheme = null;
  try { savedTheme = localStorage.getItem("seniorbazaar-theme"); } catch (e) {}
  applyTheme(savedTheme || (prefersDark ? "dark" : "light"));

  if (themeBtn) {
    themeBtn.addEventListener("click", function () {
      var next = (root.getAttribute("data-theme") || "light") === "dark" ? "light" : "dark";
      applyTheme(next);
      try { localStorage.setItem("seniorbazaar-theme", next); } catch (e) {}
    });
  }

  // 2. Mobile Menu Navigation
  var menuBtn = document.getElementById("menu-btn");
  var links = document.getElementById("links");
  if (menuBtn && links) {
    menuBtn.addEventListener("click", function () {
      var isOpen = links.classList.toggle("open");
      menuBtn.setAttribute("aria-expanded", isOpen ? "true" : "false");
      menuBtn.textContent = isOpen ? "✕" : "☰";
    });
    links.addEventListener("click", function (e) {
      if (e.target.closest("a")) {
        links.classList.remove("open");
        menuBtn.textContent = "☰";
        menuBtn.setAttribute("aria-expanded", "false");
      }
    });
  }

  // 3. Toast Notifications
  window.toast = function (msg, type) {
    var box = document.getElementById("toasts");
    if (!box) {
      box = document.createElement("div");
      box.id = "toasts";
      box.className = "toast-box";
      document.body.appendChild(box);
    }
    var t = document.createElement("div");
    t.className = "toast" + (type === "error" ? " error" : "");
    t.textContent = msg;
    box.appendChild(t);
    setTimeout(function () {
      t.classList.add("out");
      setTimeout(function () { t.remove(); }, 250);
    }, 3000);
  };

  // 4. Back to Top Button
  var toTop = document.getElementById("to-top");
  if (toTop) {
    window.addEventListener("scroll", function () {
      toTop.classList.toggle("show", window.scrollY > 350);
    }, { passive: true });
    toTop.addEventListener("click", function (e) {
      e.preventDefault();
      window.scrollTo({ top: 0, behavior: "smooth" });
    });
  }
})();
