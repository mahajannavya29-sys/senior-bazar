/**
 * SeniorBazaar - Browse & Search Logic
 * Real-time search, category filtering, sorting, and donation filter.
 */

var currentCategory = "all";

function setCategory(cat) {
  currentCategory = (cat !== "all" && !CATEGORIES[cat]) ? "all" : cat;
  $$(".subnav button").forEach(function(btn) {
    btn.classList.toggle("active", Boolean(btn.dataset && btn.dataset.cat === currentCategory));
  });
  renderItems();
}

function renderItems() {
  var query = ($("#search") ? $("#search").value : "").trim().toLowerCase();
  var freeOnly = $("#freeOnly") ? $("#freeOnly").checked : false;
  var sort = $("#sort") ? $("#sort").value : "new";

  var list = allItems().filter(function(it) {
    if (currentCategory !== "all" && it.category !== currentCategory) return false;
    if (freeOnly && it.price !== 0) return false;
    var catName = (CATEGORIES[it.category] || {}).label || "";
    return (it.title + " " + it.desc + " " + it.name + " " + catName).toLowerCase().indexOf(query) !== -1;
  });

  list.sort(function(a, b) {
    if (sort === "low") return a.price - b.price;
    if (sort === "high") return b.price - a.price;
    if (sort === "az") return a.title.localeCompare(b.title);
    return b.id - a.id;
  });

  var grid = $("#items");
  if (grid) {
    grid.innerHTML = "";
    list.forEach(function(it) { grid.appendChild(makeCard(it, true)); });
    grid.hidden = list.length === 0;
  }
  if ($("#empty")) $("#empty").hidden = list.length > 0;
  if ($("#count")) $("#count").textContent = list.length + (list.length === 1 ? " item found" : " items found");
}

(function initBrowse() {
  $$(".subnav button").forEach(function(btn) {
    btn.addEventListener("click", function() { setCategory(btn.dataset.cat); });
  });

  if ($("#search")) $("#search").addEventListener("input", renderItems);
  if ($("#sort")) $("#sort").addEventListener("change", renderItems);
  if ($("#freeOnly")) $("#freeOnly").addEventListener("change", renderItems);

  if ($("#resetFilters")) {
    $("#resetFilters").addEventListener("click", function() {
      if ($("#search")) $("#search").value = "";
      if ($("#freeOnly")) $("#freeOnly").checked = false;
      setCategory("all");
    });
  }

  bindItemButtons($("#items"), renderItems);

  var urlCat = window.URLSearchParams && window.location.search ? new URLSearchParams(window.location.search).get("cat") : null;
  setCategory(urlCat || "all");

  var flash = safeGet("sb-flash");
  if (flash) {
    safeSet("sb-flash", "");
    setTimeout(function() { if (window.toast) window.toast(flash); }, 250);
  }
})();
